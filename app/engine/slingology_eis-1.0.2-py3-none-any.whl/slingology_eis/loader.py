"""
loader.py — Garmin G3X EIS log parser and normaliser.

Loads one or more G3X CSV files into typed, normalised DataFrames.
Handles the two-row header format (row 0: airframe metadata,
row 1: column names, row 2+: 1-second data records).

Usage
-----
    from slingology_eis.loader import load_log, load_directory

    df = load_log("data/logs/log_20260518_195524_KAWO.csv")
    all_flights = load_directory("data/logs/")
"""

from __future__ import annotations

import hashlib
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import pandas as pd
import numpy as np

from . import exclusions as _exclusions
from .limits import resolve_min_flight_duration_min
from .phases import detect_phases


# ── Column renaming: G3X names → short aliases ───────────────────────────────

COLUMN_MAP = {
    "Date (yyyy-mm-dd)":          "date",
    "Time (hh:mm:ss)":            "time",
    "UTC Time (hh:mm:ss)":        "utc_time",
    "UTC Offset (hh:mm)":         "utc_offset",
    "Latitude (deg)":             "lat",
    "Longitude (deg)":            "lon",
    "GPS Altitude (ft)":          "gps_alt_ft",
    "GPS Ground Speed (kt)":      "gnd_spd_kt",
    "GPS Ground Track (deg)":     "track_deg",
    "Pressure Altitude (ft)":     "press_alt_ft",
    "Baro Altitude (ft)":         "baro_alt_ft",
    "Vertical Speed (ft/min)":    "vs_fpm",
    "Indicated Airspeed (kt)":    "ias_kt",
    "True Airspeed (kt)":         "tas_kt",
    "Pitch (deg)":                "pitch_deg",
    "Roll (deg)":                 "roll_deg",
    "Lateral Acceleration (G)":   "lat_g",
    "Normal Acceleration (G)":    "norm_g",
    "AOA Cp":                     "aoa_cp",
    "AOA":                        "aoa",
    "Outside Air Temp (deg C)":   "oat_c",
    "Density Altitude (ft)":      "da_ft",
    "Baro Setting (inch Hg)":     "baro_inhg",
    "Wind Speed (kt)":            "wind_spd_kt",
    "Wind Direction (deg)":       "wind_dir_deg",
    # ── Engine parameters ──────────────────────────────────────────────────────
    "RPM":                        "rpm",
    "Engine Power (%)":           "power_pct",
    "Manifold Press (inch Hg)":   "map_inhg",
    "Oil Press (PSI)":            "oil_press_psi",
    "Oil Temp (deg F)":           "oil_temp_f",
    "Coolant Temp (deg F)":       "coolant_temp_f",
    "Fuel Qty L (gal)":           "fuel_qty_l_gal",
    "Fuel Qty R (gal)":           "fuel_qty_r_gal",
    "Fuel Flow (gal/hour)":       "fuel_flow_gph",
    "Fuel Press (PSI)":           "fuel_press_psi",
    "EGT1 (deg F)":               "egt1_f",
    "EGT2 (deg F)":               "egt2_f",
    "EGT3 (deg F)":               "egt3_f",
    "EGT4 (deg F)":               "egt4_f",
    "Flap Position":              "flap_pos",
    "Elevator Trim":              "elev_trim",
    "Efis Bkup Volts":            "efis_bkup_v",
    "Nav Bkup Volts":             "nav_bkup_v",
    "Main Volts":                 "main_volts",
    "Batt Amps":                  "batt_amps",
    "Co Ppm":                     "co_ppm",
    # ── Discrete channels ─────────────────────────────────────────────────────
    "EFIS ON BKUP (discrete)":    "efis_on_bkup",
    "NAV ON BKUP (discrete)":     "nav_on_bkup",
    "ARM BKUP (discrete)":        "arm_bkup",
    "PITOT HEAT (discrete)":      "pitot_heat",
    "FPCM FAULT (discrete)":      "fpcm_fault",
    "CHECK FUEL (discrete)":      "check_fuel",
    "ALT FAIL (discrete)":        "alt_fail",
    "EARTH X FAIL (discrete)":    "earth_x_fail",
    "CAS Alert":                  "cas_alert",
    "Terrain Alert":              "terrain_alert",
    "Autopilot State":            "ap_state",
    "Active Nav Source":          "nav_source",
    "Network Status":             "network_status",
}

# Numeric columns (attempt float conversion)
NUMERIC_COLS = [
    "lat", "lon", "gps_alt_ft", "gnd_spd_kt", "track_deg",
    "press_alt_ft", "baro_alt_ft", "vs_fpm", "ias_kt", "tas_kt",
    "pitch_deg", "roll_deg", "lat_g", "norm_g", "aoa_cp", "aoa",
    "oat_c", "da_ft", "baro_inhg", "wind_spd_kt", "wind_dir_deg",
    "rpm", "power_pct", "map_inhg", "oil_press_psi", "oil_temp_f",
    "coolant_temp_f", "fuel_qty_l_gal", "fuel_qty_r_gal",
    "fuel_flow_gph", "fuel_press_psi",
    "egt1_f", "egt2_f", "egt3_f", "egt4_f",
    "main_volts", "batt_amps", "co_ppm", "elev_trim",
    "efis_bkup_v", "nav_bkup_v", "flap_pos",
]

# ── Garmin AXIS (Spec 01 v0.23 §6.5) → the same registry ids ───────────────────
# Every AXIS column with a registry equivalent; the rest keep their AXIS
# names (like unmapped G3X columns) and are not part of the contract.
AXIS_COLUMN_MAP = {
    "localDate":                         "date",
    "localTime":                         "time",
    "utcOffset":                         "utc_offset",
    "latitudePosition":                  "lat",
    "longitudePosition":                 "lon",
    "gpsWgs84Altitude":                  "gps_alt_ft",
    "groundSpeed":                       "gnd_spd_kt",
    "trueGpsGroundTrack":                "track_deg",
    "trueTrack":                         "track_deg",   # the aircraft log's name for it (v0.25)
    "pressureAltitude":                  "press_alt_ft",
    "indicatedBarometricAltitude":       "baro_alt_ft",
    "verticalSpeed":                     "vs_fpm",
    "indicatedAirspeed":                 "ias_kt",
    "trueAirspeed":                      "tas_kt",
    "attitudePitchAngle":                "pitch_deg",
    "attitudeRollAngle":                 "roll_deg",
    "lateralYAcceleration":              "lat_g",
    "verticalZAcceleration":             "norm_g",
    "aoa":                               "aoa",
    "outsideAirTemperature":             "oat_c",
    "densityAltitude":                   "da_ft",
    "selectedBarometricPressureSetting": "baro_inhg",
    "windSpeed":                         "wind_spd_kt",
    "windDirection":                     "wind_dir_deg",
    # Engine
    "engine1RevolutionsPerMinute":       "rpm",
    "engine1PowerPercent":               "power_pct",
    "engine1ManifoldPressure":           "map_inhg",
    "engine1OilPressure":                "oil_press_psi",
    "engine1OilTemperature":             "oil_temp_f",
    "engine1CoolantTemp":                "coolant_temp_f",
    "fuelLevel1":                        "fuel_qty_l_gal",
    "fuelLevel2":                        "fuel_qty_r_gal",
    "engine1FuelFlow":                   "fuel_flow_gph",
    "engine1FuelPressure":               "fuel_press_psi",
    "engine1ThrottlePosition":           "throttle_pct",   # aircraft log (v0.25); raw, not charted by default
    "engine1ExhaustGasTemperature1":     "egt1_f",
    "engine1ExhaustGasTemperature2":     "egt2_f",
    "engine1ExhaustGasTemperature3":     "egt3_f",
    "engine1ExhaustGasTemperature4":     "egt4_f",
    "flapPosition":                      "flap_pos",
    "elevatorTrim":                      "elev_trim",
    # Electrical: Volts1 is the main bus (13.7–13.9 V in flight, as the
    # G3X "Main Volts"); Amps2 is the only current sensor, as the G3X's
    # single "Batt Amps". Volts2 has no registry equivalent and stays raw.
    "engine1Volts1":                     "main_volts",
    "engine1Amps2":                      "batt_amps",
    # Annunciations
    "crewAlertingSystemAlert":           "cas_alert",
    "autopilotState":                    "ap_state",
    "activeNavSource":                   "nav_source",
    # AXIS-only, carried raw; not used by phase detection or admission (Q10)
    "onGroundState":                     "on_ground",
    "flightTime":                        "flight_time_h",
    "e1TachTime":                        "tach_time_h",
}
_AXIS_GP_ANALOG = re.compile(r"^engine1GeneralPurposeAnalog(\d+)$")
AXIS_NUMERIC_COLS = ["flight_time_h", "tach_time_h", "throttle_pct"]
# The Garmin Pilot "aircraft log" (Spec 01 v0.25 §6.5): its name carries the
# ident, `aircraft-log-<IDENT>-<UTC start>.csv`; a renamed file has none.
_AIRCRAFT_LOG_NAME = re.compile(r"^aircraft-log-(.+)-\d{4}-\d{2}-\d{2}T\d{6}(?:\s*\(\d+\))?\.csv$", re.IGNORECASE)
AXIS_FORMATS = ("axis", "aircraft_log")
# Never resampled-in by interpolation: text, booleans and annunciations.
# AXIS CAS wording that differs from the G3X's (Spec 01 v0.24 §6.5), so a
# CAS event, filter or Journal entry has one name per alert. Unknown tokens
# pass through. `TER N/A` holds a "/" — the separator AXIS joins alerts with
# — so it is matched before the string is split and gets a slash-free name
# (the G3X logs no terrain alerts to borrow one from).
AXIS_CAS_ALIASES = {
    "EFIS ON BACKUP": "EFIS ON BKUP",
    "NAV ON BACKUP": "NAV ON BKUP",
    "TER N/A": "TER NA",
}
_AXIS_CAS_SLASHED = sorted((k for k in AXIS_CAS_ALIASES if "/" in k), key=len, reverse=True)


def _normalise_axis_cas(value):
    """An AXIS CAS string in G3X form: aliases applied, tokens joined with
    " / " (AXIS joins them with a bare "/")."""
    if not isinstance(value, str) or not value.strip():
        return value
    for raw in _AXIS_CAS_SLASHED:
        value = value.replace(raw, AXIS_CAS_ALIASES[raw])
    tokens = [t.strip() for t in value.split("/") if t.strip()]
    return " / ".join(AXIS_CAS_ALIASES.get(t, t) for t in tokens)


_CARRY_FORWARD_COLS = {"date", "time", "utc_offset", "cas_alert", "ap_state", "nav_source", "on_ground"}

EGT_COLS   = ["egt1_f", "egt2_f", "egt3_f", "egt4_f"]
ENGINE_COLS = ["rpm", "power_pct", "map_inhg", "oil_press_psi", "oil_temp_f",
               "coolant_temp_f", "fuel_flow_gph", "fuel_press_psi"] + EGT_COLS


# ── Airframe metadata parser ──────────────────────────────────────────────────

@dataclass
class AirframeInfo:
    """Metadata from row 0 of the G3X CSV."""
    aircraft_ident: str = ""
    product: str = ""
    software_version: str = ""
    system_id: str = ""
    unit: str = ""
    airframe_hours: Optional[float] = None
    engine_hours: Optional[float] = None
    # The hour meter at the last row, when the header records it (the
    # aircraft log's tach1In, Spec 01 v0.26); else the end is estimated.
    engine_hours_end: Optional[float] = None
    log_version: str = ""
    source_format: str = "unknown"   # "g3x_direct" | "garmin_pilot" | "axis" | "aircraft_log" | "unknown"
    # AXIS frames are put on a 1 s grid (Spec 01 §6.5); share of rows filled.
    filled_share: float = 0.0
    raw: dict = field(default_factory=dict)

    @classmethod
    def from_row(cls, row_text: str) -> "AirframeInfo":
        """Parse the metadata row into an AirframeInfo."""
        # Format: key="value", key="value", ...
        pairs = re.findall(r'(\w+)="([^"]*)"', row_text)
        d = {k: v for k, v in pairs}
        try:
            af_h = float(d.get("airframe_hours", "").replace(",", "."))
        except ValueError:
            af_h = None
        try:
            eng_h = float(d.get("engine_hours", "").replace(",", "."))
        except ValueError:
            eng_h = None
        return cls(
            # AXIS writes the ident as tail_number and the product key
            # capitalised (Spec 01 §6.5).
            aircraft_ident=d.get("aircraft_ident", "") or d.get("tail_number", ""),
            product=d.get("product", "") or d.get("Product", ""),
            software_version=d.get("software_version", ""),
            system_id=d.get("system_id", ""),
            unit=d.get("unit", ""),
            airframe_hours=af_h,
            engine_hours=eng_h,
            log_version=d.get("log_version", ""),
            raw=d,
        )
# ── Source format detection ────────────────────────────────────────────────────

def _detect_source_format(header_row: str, meta: Optional[dict] = None, third_row: str = "") -> str:
    """
    Identify which export path produced this CSV.

    g3x_direct   — downloaded straight from the G3X SD card; header row
                   starts directly with 'Date (yyyy-mm-dd)'
    garmin_pilot — exported/shared via the Garmin Pilot app; header row
                   is prefixed with '#', e.g. '#Date (yyyy-mm-dd)'
    axis         — a Garmin AXIS SD-card log: Product="AXIS", a '#' units
                   row, then camelCase column names including localDate/localTime
    aircraft_log — the log the AXIS hands to Garmin Pilot / flyGarmin:
                   '#hobbsOut=…' metadata, a '#' units row, then column
                   names beginning 'timestamp,localDate,' (Spec 01 v0.25)
    unknown      — no pattern matched (flag for manual inspection
                   rather than silently guessing)
    """
    stripped = header_row.lstrip("\ufeff")  # tolerate a UTF-8 BOM from Excel re-saves
    if (meta or {}).get("_aircraft_log") and stripped.startswith("#") \
            and third_row.lstrip("\ufeff").startswith("timestamp,localDate,"):
        return "aircraft_log"
    # Garmin AXIS (Spec 01 §6.5): Product="AXIS" in the metadata, a
    # '#'-prefixed units row, then camelCase column names.
    product = ((meta or {}).get("Product") or (meta or {}).get("product") or "").strip()
    # The column set varies between AXIS logs (v0.24), so the column row is
    # recognised by the names it holds, never by their position.
    columns = {c.strip().lstrip("#") for c in third_row.split(",")}
    if product.upper() == "AXIS" and stripped.startswith("#") and {"localDate", "localTime"} <= columns:
        return "axis"
    if stripped.startswith("#Date"):
        return "garmin_pilot"
    if stripped.startswith("Date "):
        return "g3x_direct"
    return "unknown"


# ── Core loader ───────────────────────────────────────────────────────────────

def load_log_bytes(
    data: bytes,
    filename: str,
    tz_aware: bool = False,
    max_fill_gap_s: float = 2,
    channel_assignments: Optional[dict] = None,
) -> tuple[pd.DataFrame, AirframeInfo]:
    """
    Load a single G3X EIS log from raw bytes — no filesystem access.

    This is the core parser. `load_log(path)` is a thin wrapper that
    reads a file's bytes and calls this. Hosts that don't have a local
    path (a browser `File`, an HTTP upload) call this directly.

    Supports both export paths transparently:
      • g3x_direct   — CSV downloaded directly from the G3X SD card
      • garmin_pilot — CSV exported/shared through the Garmin Pilot app
                       (header row prefixed with '#')

    The detected format is recorded on `info.source_format` so you can
    confirm which path produced a given file, but no other behaviour
    differs between the two — both normalise to identical columns.

    Parameters
    ----------
    data : bytes
        Raw file contents.
    filename : str
        Name to record as `_source_file` and to use in error messages —
        purely descriptive, not read from disk.

    Returns
    -------
    df : pd.DataFrame
        1-row-per-second data, typed and normalised.
        Includes derived columns: `datetime`, `elapsed_s`,
        `egt_spread_f`, `egt_max_f`, `egt_min_f`, `egt_mean_f`,
        `fuel_flow_lph` (litres/hour for OM limit comparisons).
    info : AirframeInfo
        Parsed metadata from the file header, including `source_format`.
    """
    import io

    text = data.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)
    meta_row   = buf.readline()
    header_row = buf.readline()
    third_row  = buf.readline()

    if meta_row.lstrip("\ufeff").startswith("#hobbsOut="):
        info = _aircraft_log_info(meta_row, filename)
    else:
        info = AirframeInfo.from_row(meta_row)
    info.source_format = _detect_source_format(header_row, info.raw, third_row)
    info.raw.pop("_aircraft_log", None)

    if info.source_format == "unknown":
        raise ValueError(
            f"{filename}: unrecognised header format — expected a G3X-direct "
            f"download ('Date (yyyy-mm-dd)...'), a Garmin Pilot export "
            f"('#Date (yyyy-mm-dd)...'), a Garmin AXIS SD-card log (Product=\"AXIS\", "
            f"a '#' units row, then 'localDate,...') or a Garmin Pilot aircraft log "
            f"('#hobbsOut=...', a '#' units row, then 'timestamp,localDate,...'). "
            f"Got: {header_row[:60]!r}. "
            f"This file may be corrupted or from an unsupported source."
        )

    if info.source_format in AXIS_FORMATS:
        return _load_axis(text, filename, info, max_fill_gap_s, channel_assignments)

    # Read data (skip metadata row, row 1 is headers)
    df = pd.read_csv(io.StringIO(text), skiprows=1, low_memory=False)

    # Garmin Pilot exports prefix the header row with '#' (e.g. "#Date (yyyy-mm-dd)")
    # while direct G3X SD-card downloads do not. Strip it — along with any stray
    # whitespace from spreadsheet round-trips — so both formats normalise to the
    # same column names regardless of source_format.
    df.columns = [str(c).lstrip("#").strip() for c in df.columns]

    # Drop the sub-header row if present (some firmware versions insert one)
    first_col = df.columns[0]
    mask = df[first_col].astype(str).str.contains("Lcl Date|Date", na=False)
    df = df[~mask].reset_index(drop=True)

    # Rename columns
    df = df.rename(columns=COLUMN_MAP)

    # Drop columns not in our map (keep them for completeness but don't rename)
    # (Any unmapped columns stay with their original name)

    # ── Datetime ──────────────────────────────────────────────────────────────
    df["datetime"] = pd.to_datetime(
        df["date"].astype(str) + " " + df["time"].astype(str),
        format="%Y-%m-%d %H:%M:%S",
        errors="coerce"
    )
    df = df.dropna(subset=["datetime"]).reset_index(drop=True)
    df["elapsed_s"] = (df["datetime"] - df["datetime"].iloc[0]).dt.total_seconds()

    # ── Numeric conversion ────────────────────────────────────────────────────
    for col in NUMERIC_COLS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    return _finish_frame(df, filename), info


def _finish_frame(df: pd.DataFrame, filename: str) -> pd.DataFrame:
    """Derived columns and source metadata — the same for every source."""
    # ── Derived columns ───────────────────────────────────────────────────────
    # EGT analytics
    egt_avail = [c for c in EGT_COLS if c in df.columns]
    if egt_avail:
        df["egt_max_f"]    = df[egt_avail].max(axis=1)
        df["egt_min_f"]    = df[egt_avail].min(axis=1)
        df["egt_mean_f"]   = df[egt_avail].mean(axis=1)
        df["egt_spread_f"] = df["egt_max_f"] - df["egt_min_f"]

    # Fuel flow in litres/hour (for OM EGT-split limit which uses L/hr)
    if "fuel_flow_gph" in df.columns:
        df["fuel_flow_lph"] = df["fuel_flow_gph"] * 3.78541

    # OAT in Fahrenheit
    if "oat_c" in df.columns:
        df["oat_f"] = df["oat_c"] * 9/5 + 32

    # MAP in hPa (for OM limit comparisons which use hPa)
    if "map_inhg" in df.columns:
        df["map_hpa"] = df["map_inhg"] * 33.8639

    # Oil temp in Celsius
    if "oil_temp_f" in df.columns:
        df["oil_temp_c"] = (df["oil_temp_f"] - 32) * 5/9

    # Coolant temp in Celsius
    if "coolant_temp_f" in df.columns:
        df["coolant_temp_c"] = (df["coolant_temp_f"] - 32) * 5/9

    # EGT in Celsius
    for col in egt_avail:
        df[col.replace("_f", "_c")] = (df[col] - 32) * 5/9

    # Source file metadata
    df["_source_file"] = filename

    return df


def _load_axis(text: str, filename: str, info: AirframeInfo, max_fill_gap_s: float,
               channel_assignments: Optional[dict]) -> tuple[pd.DataFrame, AirframeInfo]:
    """A Garmin AXIS export (Spec 01 §6.5): metadata · units · column names ·
    ~0.83 Hz rows. Normalised to the registry ids and put on a 1-second
    grid so that every downstream module sees the same frame as for a G3X
    log. General-purpose analog inputs enter raw (`gp_analog_<n>`) and are
    exposed under a registry id only through a channel assignment."""
    import io

    # Skip the metadata and units rows; row 3 holds the column names.
    df = pd.read_csv(io.StringIO(text), skiprows=2, low_memory=False)
    df.columns = [str(c).lstrip("#").strip() for c in df.columns]
    renames = dict(AXIS_COLUMN_MAP)
    gp_ids = []
    for c in df.columns:
        m = _AXIS_GP_ANALOG.match(c)
        if m:
            renames[c] = f"gp_analog_{int(m.group(1))}"
            gp_ids.append(renames[c])
    df = df.rename(columns=renames)
    # A column name mapped twice (an SD-card and an aircraft-log alias in one
    # file) keeps its first occurrence.
    df = df.loc[:, ~df.columns.duplicated()]

    if info.source_format == "aircraft_log":
        df["datetime"] = _aircraft_log_datetime(df)
    else:
        df["datetime"] = pd.to_datetime(
            df["date"].astype(str) + " " + df["time"].astype(str),
            format="%Y-%m-%d %H:%M:%S",
            errors="coerce",
        )
    df = df.dropna(subset=["datetime"]).reset_index(drop=True)
    if info.source_format == "aircraft_log":
        # The local columns are unreliable in this format (they lag and
        # drift against `timestamp`); rewrite them from the clock in use.
        df["date"] = df["datetime"].dt.strftime("%Y-%m-%d")
        df["time"] = df["datetime"].dt.strftime("%H:%M:%S")
    for col in NUMERIC_COLS + AXIS_NUMERIC_COLS + gp_ids:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    if "on_ground" in df.columns:
        df["on_ground"] = df["on_ground"].astype(str).str.strip().str.lower().map({"true": True, "false": False})

    if "cas_alert" in df.columns:
        df["cas_alert"] = df["cas_alert"].map(_normalise_axis_cas)

    df, filled_share = _resample_1hz(df, max_fill_gap_s)
    df = df.copy()   # one block, not dozens of per-column inserts
    df["elapsed_s"] = (df["datetime"] - df["datetime"].iloc[0]).dt.total_seconds()
    info.filled_share = filled_share

    # Engine hours: the tach time at the start (the same hour meter the G3X
    # wrote into its header); there is no airframe-hours field. The aircraft
    # log's header carries it as tach1Out (equal to its first e1TachTime).
    if info.source_format == "aircraft_log" and info.engine_hours is not None:
        pass
    elif "tach_time_h" in df.columns and df["tach_time_h"].notna().any():
        info.engine_hours = float(df["tach_time_h"].dropna().iloc[0])
    info.airframe_hours = None

    _apply_channel_assignments(df, channel_assignments)
    return _finish_frame(df, filename), info


def _aircraft_log_info(meta_row: str, filename: str) -> AirframeInfo:
    """The aircraft log's metadata row (Spec 01 v0.25 §6.5): only hour-meter
    readings, `#hobbsOut=,hobbsIn=,tach1Out=127.3,…`. engine_hours is
    tach1Out; the ident comes from the file name; the product is AXIS."""
    d = {}
    for part in meta_row.strip().lstrip("\ufeff").lstrip("#").split(","):
        if "=" in part:
            k, v = part.split("=", 1)
            d[k.strip()] = v.strip()
    try:
        eng_h = float(d.get("tach1Out", ""))
    except ValueError:
        eng_h = None
    try:
        eng_h_end = float(d.get("tach1In", ""))
    except ValueError:
        eng_h_end = None
    m = _AIRCRAFT_LOG_NAME.match(Path(filename).name)
    return AirframeInfo(
        aircraft_ident=m.group(1) if m else "",
        product="AXIS",
        engine_hours=eng_h,
        engine_hours_end=eng_h_end,
        airframe_hours=None,
        raw={**d, "_aircraft_log": True},
    )


def _aircraft_log_datetime(df: pd.DataFrame) -> pd.Series:
    """The aircraft log's clock (Spec 01 v0.25 §6.5): `timestamp` (ISO-8601
    UTC, milliseconds), never `localDate`/`localTime`. Shifted by the log's
    constant `utcOffset` so the frame is on the same local basis as the
    SD-card log and the G3X, and rounded to the second; the 1 s reindexing
    then absorbs the ±30 ms jitter."""
    ts = pd.to_datetime(df["timestamp"], utc=True, errors="coerce", format="ISO8601")
    offset = pd.Timedelta(0)
    if "utc_offset" in df.columns:
        vals = df["utc_offset"].dropna().astype(str).str.strip()
        vals = vals[vals.str.match(r"^[+-]\d{2}:\d{2}$")]
        if len(vals):
            o = vals.mode().iloc[0]
            sign = -1 if o[0] == "-" else 1
            offset = sign * pd.Timedelta(hours=int(o[1:3]), minutes=int(o[4:6]))
    return (ts + offset).dt.tz_localize(None).dt.round("1s")


def assignment_target(value) -> Optional[str]:
    """The registry channel of one channel assignment: a bare id
    ("co_ppm") or {"channel": "co_ppm", "ignore_value": 254} (Spec 01 v0.25)."""
    if isinstance(value, dict):
        return value.get("channel") or None
    return value or None


def assignment_ignore_value(value) -> Optional[float]:
    """The one sentinel an assignment treats as "not a reading", if any."""
    if isinstance(value, dict) and value.get("ignore_value") is not None:
        try:
            return float(value["ignore_value"])
        except (TypeError, ValueError):
            return None
    return None


def _apply_channel_assignments(df: pd.DataFrame, channel_assignments: Optional[dict]) -> None:
    """Spec 01 §6.5: a host-supplied {raw_id: registry_id} exposes a raw
    general-purpose channel under a registry id — only for a raw channel
    this frame has, and only for a registry channel it lacks natively. An
    assignment may carry one ignore value (v0.25): rows holding it are
    missing under the assigned name; the raw channel keeps them."""
    for raw, value in (channel_assignments or {}).items():
        target = assignment_target(value)
        if not str(raw).startswith("gp_analog_") or raw not in df.columns:
            continue
        if not target or target in df.columns:
            continue
        series = df[raw]
        ignore = assignment_ignore_value(value)
        if ignore is not None:
            series = series.where(series != ignore)
        df[target] = series


def _resample_1hz(df: pd.DataFrame, max_fill_gap_s: float) -> tuple[pd.DataFrame, float]:
    """Reindex onto a 1-second grid from the first to the last timestamp
    (Spec 01 §6.5 decision 1). Numeric channels are interpolated across
    holes of at most `max_fill_gap_s`; text, boolean and CAS channels carry
    the previous value forward across the same holes; longer holes stay
    missing. Filled rows are marked in `_filled`. Returns (frame, share)."""
    df = df.drop_duplicates(subset="datetime", keep="first").set_index("datetime")
    grid = pd.date_range(df.index[0], df.index[-1], freq="1s")
    out = df.reindex(grid)
    missing = ~out.index.isin(df.index)
    # Length of each run of missing seconds, per row.
    run_id = (missing != np.roll(missing, 1)).cumsum()
    run_len = pd.Series(missing).groupby(run_id).transform("sum").to_numpy()
    fillable = missing & (run_len <= max_fill_gap_s)
    limit = max(int(max_fill_gap_s), 0)
    for col in out.columns:
        numeric = pd.api.types.is_numeric_dtype(df[col]) and not pd.api.types.is_bool_dtype(df[col])
        if col in _CARRY_FORWARD_COLS or not numeric or not pd.api.types.is_numeric_dtype(out[col]):
            filled = out[col].ffill(limit=limit) if limit else out[col]
        else:
            filled = out[col].interpolate(method="time", limit=limit, limit_area="inside") if limit else out[col]
        # Only holes up to the limit are filled; rows of longer holes stay missing.
        out[col] = out[col].where(~fillable, filled)
    out["_filled"] = fillable
    out = out.rename_axis("datetime").reset_index()
    share = float(fillable.mean()) if len(fillable) else 0.0
    return out, share


def load_log(
    path: str | Path,
    tz_aware: bool = False,
) -> tuple[pd.DataFrame, AirframeInfo]:
    """
    Load a single G3X EIS log file from disk.

    Thin wrapper around `load_log_bytes()` — reads the file's bytes and
    delegates. See `load_log_bytes()` for parsing details.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Log not found: {path}")
    return load_log_bytes(path.read_bytes(), path.name, tz_aware=tz_aware)


def load_directory(
    directory: str | Path,
    pattern: str = "*.csv",
    skip_ground_sessions: bool = True,
    workspace_dir: Optional[Path] = None,
    verbose: bool = True,
) -> list[tuple[pd.DataFrame, AirframeInfo]]:
    """
    Load all G3X log files from a directory.

    Matches the given pattern case-insensitively (so '*.csv' also picks up
    '.CSV', '.Csv', etc. — Garmin Pilot and some OS file pickers vary in
    the case they save with). Files are de-duplicated by resolved path so
    a case-insensitive match never double-counts the same file.

    Parameters
    ----------
    skip_ground_sessions : bool, default True
        Exclude ground-only sessions, short flights, and files with a
        large internal time gap (see workspace_dir below) — none of these
        have useful flight analytics, and including them produces
        misleading results in every downstream module (false temperature
        outliers, meaningless phase labels, blank cells across most
        analytics columns; short flights and ground sessions also inflate
        counts and degrade trend quality with x-axis points at identical
        engine-hours).

        Ground-session detection (Spec 02 §5.11.2): a file
        is excluded if and only if `detect_phases()` finds no row in an
        airborne phase (`phases.AIRBORNE_PHASES` — CLIMB, CRUISE, DESCENT,
        APPROACH, LANDING_ROLL; deliberately not TAKEOFF_ROLL, which is
        reachable from a ground run-up alone with no confirmed liftoff —
        see the comment on AIRBORNE_PHASES). This replaced an earlier
        RPM/IAS threshold approximation that was a proxy for what the phase
        detector already answers definitively — same state machine that
        labels the rest of the flight, not a second, cruder opinion.

        Pass skip_ground_sessions=False only if you specifically need to
        examine ground sessions (e.g. for ENGINE ECU start-up behavior
        in isolation from flight operations — but note that full flights
        contain all the same GROUND_START/LANE_CHECK/GROUND_SHUTDOWN patterns and are
        sufficient to establish those baselines without the noise). This
        also disables the short-flight and time-gap checks below, and
        exclusions.json is neither read nor written.

    workspace_dir : Path, optional
        Spec 02 §5.11. When given (and
        skip_ground_sessions is True), every exclusion decision is looked
        up and recorded in `workspace_dir/exclusions.json` (see
        `exclusions.py`) instead of being silently dropped:
          - A file with an existing entry (any category, auto or user) is
            skipped without re-parsing or re-running phase detection —
            the answer is already on record.
          - A newly-detected ground session, short flight (airborne time
            below `min_flight_duration_min` from the toolkit's
            config.json, default 10 min, 0 disables the check), or file
            with an internal time gap over 5 minutes (a strong signal of
            a mid-session avionics restart or SD card error —
            `corrupt_log`) gets a fresh auto-exclusion entry written
            before being skipped.
          - Ground session takes priority over short flight, which takes
            priority over the time-gap check, when more than one would
            apply — one entry per file, not a pile-up.
        A `user_override: true` entry (set via
        `exclusions.set_user_override`) always keeps its flight in the
        results despite matching one of the rules above. When
        workspace_dir is None (the default), only the ground-session rule
        applies (Spec 02 §5.11.2): auto-detect and skip, but don't persist
        anything.

    Returns a list of (DataFrame, AirframeInfo) tuples, sorted
    chronologically by the datetime of the first record. Every DataFrame
    carries a populated `phase` column (`detect_phases()` runs on every
    file regardless of `skip_ground_sessions`) — downstream callers that
    already re-run `detect_phases()` on the result get the same answer,
    just redundantly; nothing breaks either way.
    """
    directory = Path(directory)

    exclusions_data = _exclusions.load_exclusions(workspace_dir) if workspace_dir is not None else None
    min_flight_duration_min = resolve_min_flight_duration_min()

    # Case-insensitive glob: build a regex from the pattern and scan once,
    # rather than relying on Path.glob (which is case-sensitive on
    # Linux/Mac and would silently skip e.g. '.CSV' files).
    import re as _re
    regex = _re.compile(
        "^" + _re.escape(pattern).replace(r"\*", ".*").replace(r"\?", ".") + "$",
        _re.IGNORECASE,
    )
    seen: set[Path] = set()
    files = []
    for f in directory.iterdir():
        if f.is_file() and regex.match(f.name):
            resolved = f.resolve()
            if resolved not in seen:
                seen.add(resolved)
                files.append(f)
    files.sort()

    if not files:
        raise ValueError(f"No files matching '{pattern}' (case-insensitive) in {directory}")

    if verbose:
        print(f"Found {len(files)} file(s) matching '{pattern}' in {directory}")

    results = []
    failed  = []
    skipped = []

    for f in files:
        try:
            filename = f.name

            # An existing exclusions.json entry (auto or user) is
            # authoritative — don't re-parse or re-run phase detection to
            # confirm what's already on record (Spec 02 §5.11.3).
            if (skip_ground_sessions and exclusions_data is not None
                    and _exclusions.is_excluded(filename, exclusions_data)):
                skipped.append(filename)
                if verbose:
                    print(f"  · {filename}  already excluded — skipped")
                continue

            df, info = load_log(f)

            # ── Phase detection ──────────────────────────────────────────────
            # Runs regardless of skip_ground_sessions so every returned
            # DataFrame carries a populated 'phase' column (Spec 02
            # §5.11.2) — ground-session status is then read
            # directly off it rather than approximated separately.
            df = detect_phases(df, verbose=False)

            if skip_ground_sessions:
                category, reason = _exclusions.classify_for_auto_exclusion(
                    df, min_flight_duration_min, check_short_flight_and_gap=workspace_dir is not None,
                )

                if category is not None and workspace_dir is not None:
                    _exclusions.add_auto_exclusion(workspace_dir, filename, category, reason)
                    # add_auto_exclusion() is a no-op if an entry already
                    # exists — which includes one a user already overrode
                    # (e.g. a prior run's auto-exclusion since flagged
                    # user_override: true). Re-check against the current
                    # on-disk state rather than the stale copy loaded at
                    # the top of this call, so that override wins here
                    # too, not just on this file's *next* run.
                    if not _exclusions.is_excluded(filename, _exclusions.load_exclusions(workspace_dir)):
                        category = None

                if category is not None:
                    skipped.append(filename)
                    if verbose:
                        print(f"  · {filename}  [{df['datetime'].iloc[0]:%Y-%m-%d %H:%M}]  "
                              f"{reason} — skipped")
                    continue

            results.append((df, info))
            if verbose:
                start = df["datetime"].iloc[0]
                end   = df["datetime"].iloc[-1]
                dur   = (end - start).total_seconds() / 60
                fmt   = {"g3x_direct": "G3X", "garmin_pilot": "GarminPilot", "axis": "AXIS",
                         "aircraft_log": "AircraftLog"}.get(
                    info.source_format, info.source_format)
                print(f"  ✓ {f.name}  [{start:%Y-%m-%d %H:%M}]  {dur:.0f} min  "
                      f"{len(df)} rows  {info.aircraft_ident}  ({fmt})")
        except Exception as e:
            failed.append((f.name, str(e)))
            if verbose:
                print(f"  ✗ {f.name}: {e}")

    # Sort by first timestamp
    results.sort(key=lambda r: r[0]["datetime"].iloc[0])
    if verbose:
        print(f"\nLoaded {len(results)} flight(s)"
              + (f", skipped {len(skipped)} ground session(s)" if skipped else "")
              + (f", {len(failed)} failed" if failed else "")
              + f"  (total files found: {len(files)})")
        if failed:
            print(f"⚠ Failed files:")
            for name, err in failed:
                print(f"    {name}: {err}")
    return results


# ── Quick summary ─────────────────────────────────────────────────────────────

def log_summary(df: pd.DataFrame, info: AirframeInfo) -> dict:
    """Return a flat summary dict for a single flight."""
    start = df["datetime"].iloc[0]
    end   = df["datetime"].iloc[-1]
    dur_s = (end - start).total_seconds()

    airborne = df[df["rpm"].fillna(0) > 3000]

    summary = {
        "aircraft":      info.aircraft_ident,
        "date":          start.date(),
        "local_start":   start,
        "local_end":     end,
        "duration_min":  dur_s / 60,
        "rows":          len(df),
        "interval_s":    df["elapsed_s"].diff().mode()[0] if len(df) > 1 else None,
        "airborne_rows": len(airborne),
        "airborne_min":  len(airborne) / 60,
        "engine_hours_at_log": info.engine_hours,
        "source_file":   df["_source_file"].iloc[0],
        "source_format": info.source_format,
    }

    # Engine peaks (airborne)
    for col, label in [
        ("rpm",          "max_rpm"),
        ("power_pct",    "max_power_pct"),
        ("egt_max_f",    "max_egt_f"),
        ("egt_spread_f", "max_egt_spread_f"),
        ("oil_temp_f",   "max_oil_temp_f"),
        ("coolant_temp_f", "max_coolant_temp_f"),
        ("map_inhg",     "max_map_inhg"),
        ("fuel_flow_gph","max_fuel_flow_gph"),
    ]:
        if col in airborne.columns:
            summary[label] = airborne[col].dropna().max() if len(airborne) else None

    # Mean fuel flow in cruise (rough: airborne, VS settled)
    cruise = airborne[
        (airborne["vs_fpm"].abs() < 300) &
        (airborne["ias_kt"] > 60)
    ] if "vs_fpm" in airborne.columns and "ias_kt" in airborne.columns else pd.DataFrame()
    summary["cruise_fuel_flow_gph"] = cruise["fuel_flow_gph"].mean() if len(cruise) else None

    return summary


# ── Duplicate flight detection ─────────────────────────────────────────────────

@dataclass
class DuplicateGroup:
    """A set of files judged to represent the same physical flight."""
    files: list[str]
    aircraft_ident: str
    overlap_start: pd.Timestamp
    overlap_end: pd.Timestamp
    match_kind: str    # "exact" | "overlap"
    detail: str

    def __str__(self):
        names = ", ".join(self.files)
        return (f"[{self.match_kind}] {self.aircraft_ident}  "
                f"{self.overlap_start:%Y-%m-%d %H:%M}–{self.overlap_end:%H:%M}  "
                f"({names})  — {self.detail}")


def source_key(data: bytes) -> str:
    """
    Identifies one exported file (Spec 01 §6.1): SHA-256 of the file
    bytes, hex, first 16 characters.
    """
    return hashlib.sha256(data).hexdigest()[:16]


def flight_id(fingerprint: tuple) -> str:
    """
    Identifies one physical flight across export paths (Spec 01 §6.1):
    an opaque hash of `flight_fingerprint()`'s output. Two files with the
    same fingerprint (e.g. an SD-card export and a Garmin Pilot export of
    the same flight) share a flight_id but differ in source_key.

    Not an anonymization mechanism — the underlying fingerprint fields
    are low-entropy. Identifying fields are carried separately in
    FlightAnalysis.header and are what the `anonymize` option strips.
    """
    aircraft_ident, system_id, start_minute = fingerprint
    canonical = f"{aircraft_ident}|{system_id}|{start_minute.isoformat() if start_minute is not None else ''}"
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]


def flight_fingerprint(df: pd.DataFrame, info: AirframeInfo) -> tuple:
    """
    A coarse identity key for a flight: same aircraft, same G3X unit,
    same start minute. Two files sharing this fingerprint are almost
    certainly the same physical flight exported through different paths
    (e.g. SD-card download vs. Garmin Pilot export) — start time alone
    can't distinguish them since both preserve the original timestamps.

    Truncated to the minute (not the second) deliberately: some export
    paths round or drop the first partial second, so an exact-second
    match is too strict and would miss genuine duplicates.
    """
    start_minute = df["datetime"].iloc[0].floor("min") if len(df) else None
    # Source identity (Spec 01 §6.1/§6.5): the G3X system_id, or the
    # product name ("AXIS") for both AXIS formats, which carry no system id.
    source_identity = info.product if info.source_format in AXIS_FORMATS else info.system_id
    return (info.aircraft_ident, source_identity, start_minute)


def find_duplicate_flights(
    flights: list[tuple[pd.DataFrame, AirframeInfo]],
    overlap_threshold: float = 0.8,
) -> list[DuplicateGroup]:
    """
    Detect flights in a loaded batch that represent the same physical
    flight, via two passes:

    1. EXACT — same aircraft + same G3X unit + same start minute.
       This catches the common case: the same flight exported once
       directly from the SD card and once via Garmin Pilot.

    2. OVERLAP — same aircraft + time windows overlap by more than
       `overlap_threshold` of the shorter flight's duration, even if
       start times differ (e.g. one export is missing the first few
       minutes of avionics-on time that the other captured).

    Returns a list of DuplicateGroup objects. An empty list means no
    duplicates were found. This does NOT decide which file to keep —
    that's a judgement call (e.g. prefer the higher row-count / more
    complete export), left to the caller.
    """
    groups: list[DuplicateGroup] = []
    seen_pairs: set[frozenset] = set()

    # ── Pass 1: exact fingerprint match ──────────────────────────────────────
    by_fingerprint: dict[tuple, list[int]] = {}
    for idx, (df, info) in enumerate(flights):
        fp = flight_fingerprint(df, info)
        by_fingerprint.setdefault(fp, []).append(idx)

    for fp, idxs in by_fingerprint.items():
        if len(idxs) > 1:
            names = [flights[i][0]["_source_file"].iloc[0] for i in idxs]
            starts = [flights[i][0]["datetime"].iloc[0] for i in idxs]
            ends   = [flights[i][0]["datetime"].iloc[-1] for i in idxs]
            row_counts = [len(flights[i][0]) for i in idxs]
            groups.append(DuplicateGroup(
                files=names,
                aircraft_ident=fp[0],
                overlap_start=min(starts),
                overlap_end=max(ends),
                match_kind="exact",
                detail=f"identical start minute; row counts: {row_counts}",
            ))
            seen_pairs.add(frozenset(idxs))

    # ── Pass 2: time-window overlap (catches near-matches the exact pass missed) ──
    n = len(flights)
    for i in range(n):
        for j in range(i + 1, n):
            key = frozenset([i, j])
            if key in seen_pairs:
                continue   # already caught by exact match

            df_a, info_a = flights[i]
            df_b, info_b = flights[j]
            if info_a.aircraft_ident != info_b.aircraft_ident:
                continue
            if not info_a.aircraft_ident:
                continue   # can't compare unknown aircraft

            a_start, a_end = df_a["datetime"].iloc[0], df_a["datetime"].iloc[-1]
            b_start, b_end = df_b["datetime"].iloc[0], df_b["datetime"].iloc[-1]

            overlap_start = max(a_start, b_start)
            overlap_end   = min(a_end, b_end)
            overlap_s = (overlap_end - overlap_start).total_seconds()
            if overlap_s <= 0:
                continue   # no time overlap at all

            a_dur = (a_end - a_start).total_seconds()
            b_dur = (b_end - b_start).total_seconds()
            shorter_dur = min(a_dur, b_dur)
            if shorter_dur <= 0:
                continue

            overlap_frac = overlap_s / shorter_dur
            if overlap_frac >= overlap_threshold:
                groups.append(DuplicateGroup(
                    files=[df_a["_source_file"].iloc[0], df_b["_source_file"].iloc[0]],
                    aircraft_ident=info_a.aircraft_ident,
                    overlap_start=overlap_start,
                    overlap_end=overlap_end,
                    match_kind="overlap",
                    detail=f"{overlap_frac*100:.0f}% time overlap "
                           f"(rows: {len(df_a)} vs {len(df_b)})",
                ))

    return groups


def deduplicate_flights(
    flights: list[tuple[pd.DataFrame, AirframeInfo]],
    prefer: str = "most_rows",
    verbose: bool = True,
) -> list[tuple[pd.DataFrame, AirframeInfo]]:
    """
    Remove duplicate flights from a loaded batch, keeping one
    representative per duplicate group.

    prefer:
        "most_rows" (default) — keep the file with more data rows,
            on the theory that a more complete capture (e.g. SD-card
            download that wasn't truncated) is the better source.
        "g3x_direct" — prefer a G3X-direct download over a Garmin
            Pilot export when both are present in the group.

    This is a convenience wrapper around find_duplicate_flights() for
    callers (like 03_multi_flight_insights.py) that just want a clean
    deduplicated list without examining the groups themselves.
    """
    dup_groups = find_duplicate_flights(flights)
    if not dup_groups:
        return flights

    # Map source_file -> index for quick lookup
    file_to_idx = {df["_source_file"].iloc[0]: i for i, (df, _) in enumerate(flights)}

    drop_indices: set[int] = set()
    for group in dup_groups:
        idxs = [file_to_idx[f] for f in group.files if f in file_to_idx]
        if len(idxs) < 2:
            continue

        if prefer == "g3x_direct":
            g3x_idxs = [i for i in idxs if flights[i][1].source_format == "g3x_direct"]
            keep = g3x_idxs[0] if g3x_idxs else max(idxs, key=lambda i: len(flights[i][0]))
        else:  # most_rows, after the source preference (Spec 01 v0.25 §6.5):
            # an aircraft log beats the AXIS SD-card log of the same flight.
            keep = max(idxs, key=lambda i: (flights[i][1].source_format == "aircraft_log", len(flights[i][0])))

        for i in idxs:
            if i != keep:
                drop_indices.add(i)

        if verbose:
            kept_name = flights[keep][0]["_source_file"].iloc[0]
            dropped_names = [flights[i][0]["_source_file"].iloc[0] for i in idxs if i != keep]
            print(f"  ⚠ Duplicate flight detected ({group.match_kind}): "
                  f"keeping '{kept_name}', dropping {dropped_names}")

    return [f for i, f in enumerate(flights) if i not in drop_indices]
