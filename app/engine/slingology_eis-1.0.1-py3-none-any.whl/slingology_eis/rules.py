"""
rules.py — validate_rules and what_if_rules (Spec 01 §7).

Pure — no I/O. Callers (the CLI, a future rule-playground UI) read the
RuleSet JSON and pass the parsed dict in.
"""
from __future__ import annotations

from typing import Optional

from .contract import Diagnostic
from .operations import FlightAnalysis, FleetAnalysis, evaluate_insights

_VALID_TRIGGER_TYPES = {"threshold", "baseline_deviation", "trend"}
_VALID_SEVERITIES = {"info", "watch", "warning", "limit"}
_VALID_TREND_DIRECTIONS = {"increasing", "decreasing", "either"}


def validate_rules(rules: dict, limit_ids: Optional[set] = None) -> list[dict]:
    """
    Schema and semantic checks on a RuleSet (insight_rules.json shape).
    Returns a list of Diagnostic dicts; empty means valid (errors use
    severity "error", looser issues "warn").

    `limit_ids` (Spec 09 §10.2): the engine profile's limit ids. When
    given, a threshold trigger's `limit_ref` that isn't one of them is an
    error. A threshold trigger may carry `limit_ref` or, in a rule set
    written before rules v1.3, a bare numeric `limit`.
    """
    diagnostics: list[Diagnostic] = []

    if not isinstance(rules, dict) or not isinstance(rules.get("rules"), dict):
        diagnostics.append(Diagnostic(
            code="RULES_SCHEMA_ERROR", severity="error", scope="file",
            message="Missing or invalid top-level 'rules' object.",
        ))
        return [d.to_dict() for d in diagnostics]

    for topic_id, topic in rules["rules"].items():
        if not isinstance(topic, dict):
            diagnostics.append(Diagnostic(
                code="RULES_SCHEMA_ERROR", severity="error", scope="topic",
                message=f"{topic_id}: rule entry must be an object.",
                refs={"topic_id": topic_id},
            ))
            continue
        if not isinstance(topic.get("enabled"), bool):
            diagnostics.append(Diagnostic(
                code="RULES_SCHEMA_ERROR", severity="warn", scope="topic",
                message=f"{topic_id}: missing or non-boolean 'enabled'.",
                refs={"topic_id": topic_id},
            ))
        applies_to = topic.get("applies_to")
        if applies_to is not None and not (
            isinstance(applies_to, list) and applies_to and all(isinstance(m, str) for m in applies_to)
        ):
            diagnostics.append(Diagnostic(
                code="RULES_SCHEMA_ERROR", severity="error", scope="topic",
                message=f"{topic_id}: 'applies_to' must be a non-empty list of metric ids.",
                refs={"topic_id": topic_id},
            ))
        # Spec 10 §4.1 (Spec 09 §10.2, v0.13): a rule-level limit_refs list,
        # resolved to this flight's limit_exceedances insight for each
        # limit (never a threshold trigger of its own). Unresolvable is an
        # error, the same as a threshold trigger's limit_ref.
        limit_refs = topic.get("limit_refs")
        if limit_refs is not None:
            if not (isinstance(limit_refs, list) and limit_refs and all(isinstance(r, str) and r for r in limit_refs)):
                diagnostics.append(Diagnostic(
                    code="RULES_SCHEMA_ERROR", severity="error", scope="topic",
                    message=f"{topic_id}: 'limit_refs' must be a non-empty list of limit id strings.",
                    refs={"topic_id": topic_id},
                ))
            elif limit_ids is not None:
                for ref in limit_refs:
                    if ref not in limit_ids:
                        diagnostics.append(Diagnostic(
                            code="RULES_LIMIT_REF_UNRESOLVED", severity="error", scope="topic",
                            message=f"{topic_id}: limit_refs entry {ref!r} is not a limit in the engine profile.",
                            refs={"topic_id": topic_id, "limit_ref": ref},
                        ))
        # Spec 08 v0.3 §6 (Spec 10 D4): cylinder_rank ships with no
        # 'triggers' key at all — it keeps margin_min_f/consecutive_flights
        # for the rule playground but emits nothing, so there's no
        # trigger list to validate. Missing means empty, not invalid.
        triggers = topic.get("triggers", [])
        if not isinstance(triggers, list):
            diagnostics.append(Diagnostic(
                code="RULES_SCHEMA_ERROR", severity="error", scope="topic",
                message=f"{topic_id}: 'triggers' must be a list.",
                refs={"topic_id": topic_id},
            ))
            continue
        for i, trig in enumerate(triggers):
            if not isinstance(trig, dict) or trig.get("type") not in _VALID_TRIGGER_TYPES:
                diagnostics.append(Diagnostic(
                    code="RULES_SCHEMA_ERROR", severity="error", scope="topic",
                    message=f"{topic_id}.triggers[{i}]: unknown or missing trigger type.",
                    refs={"topic_id": topic_id, "index": i},
                ))
                continue
            if trig["type"] == "trend" and trig.get("direction") not in _VALID_TREND_DIRECTIONS:
                diagnostics.append(Diagnostic(
                    code="RULES_SCHEMA_ERROR", severity="warn", scope="topic",
                    message=f"{topic_id}.triggers[{i}]: unknown trend direction {trig.get('direction')!r}.",
                    refs={"topic_id": topic_id, "index": i},
                ))
            if trig["type"] == "threshold" and "limit_ref" in trig:
                ref = trig["limit_ref"]
                if not isinstance(ref, str) or not ref:
                    diagnostics.append(Diagnostic(
                        code="RULES_SCHEMA_ERROR", severity="error", scope="topic",
                        message=f"{topic_id}.triggers[{i}]: 'limit_ref' must be a limit id string.",
                        refs={"topic_id": topic_id, "index": i},
                    ))
                elif limit_ids is not None and ref not in limit_ids:
                    diagnostics.append(Diagnostic(
                        code="RULES_LIMIT_REF_UNRESOLVED", severity="error", scope="topic",
                        message=f"{topic_id}.triggers[{i}]: limit_ref {ref!r} is not a limit in the engine profile.",
                        refs={"topic_id": topic_id, "index": i, "limit_ref": ref},
                    ))
            severity = trig.get("severity")
            if severity is not None and severity not in _VALID_SEVERITIES:
                diagnostics.append(Diagnostic(
                    code="RULES_SCHEMA_ERROR", severity="warn", scope="topic",
                    message=f"{topic_id}.triggers[{i}]: unknown severity {severity!r}.",
                    refs={"topic_id": topic_id, "index": i},
                ))

    return [d.to_dict() for d in diagnostics]


def what_if_rules(
    flight_analysis: FlightAnalysis,
    fleet_analysis: FleetAnalysis,
    old_rules: dict,
    new_rules: dict,
) -> dict:
    """
    Spec 01 §7 `what_if_rules` workflow: re-run evaluate_insights with a
    candidate RuleSet and diff against the currently-shipped one for one
    flight. Diffs by insight id (flight_id+topic_id+trigger+text) — a
    severity-only change on an insight that fires under both rule sets
    shows as unchanged, not as a diff; a real limitation of id-based
    diffing, not a bug, kept simple for this first pass.
    """
    old_iset = evaluate_insights(flight_analysis, fleet_analysis, old_rules)
    new_iset = evaluate_insights(flight_analysis, fleet_analysis, new_rules)

    def _by_id(iset):
        return {i["id"]: i for t in iset.topics for i in t["insights"]}

    old_ids, new_ids = _by_id(old_iset), _by_id(new_iset)
    added = [new_ids[i] for i in new_ids if i not in old_ids]
    removed = [old_ids[i] for i in old_ids if i not in new_ids]
    return {
        "flight_id": flight_analysis.flight_id,
        "added": added,
        "removed": removed,
        "unchanged_count": len(set(old_ids) & set(new_ids)),
    }
